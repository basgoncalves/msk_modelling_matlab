# MOtoNMS: Licenses #

This directory includes Licenses for tools used in MOtoNMS that are developed 
by other authors and freely available.
We would like to thank all the developers for the software that makes 
our work possible.