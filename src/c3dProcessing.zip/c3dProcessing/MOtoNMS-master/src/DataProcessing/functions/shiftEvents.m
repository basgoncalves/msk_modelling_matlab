
function shiftEvents(dirEventsMat,dirFPMat)

load(dirEventsMat)
load(dirFPMat)

FZ = FPdata.RawData (:,contains(FPdata.Labels, {'Force.Fz'}));
time = FPdata.

for i = 1:length(Events)
    
    if contains(Events(i).label,'Strike')
    
    ForceArroundEvent = FPdata.RawData Events(i).time
        
        
    else contains(Events(i).label,'Off')
        
        
    end
end