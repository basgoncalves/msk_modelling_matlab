# MOtoNMS: shared functions #

This directory includes MATLAB functions common to more than one processing step 
(i.e. Acquisition Interface, C3D2MAT, Data Processing and Static Elaboration).


